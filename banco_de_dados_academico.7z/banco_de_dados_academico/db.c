/*
    "Motor" do banco de dados.

    Este arquivo é responsável por:
    • Manipulação do arquivo binário
    • Geração de IDs
    • CRUD (Create, Read, Update, Delete)
    • Aplicação das regras de negócio
    • Exportação das funções para a DLL

    Ele é compilado como uma biblioteca dinâmica (db.dll)
    e consumido pelo Python via ctypes.
*/

#include "db.h"
#include <stdio.h>
#include <string.h>

/*
Responsável por inicializar o banco de dados.

Abre o arquivo em modo:
    "ab+" → leitura e escrita, criando se não existir.

Se o arquivo não existir, ele será criado automaticamente.
*/
EXPORT int db_init() {
    FILE *f = fopen(DB_FILE, "ab+");
    if (!f) return 0;   // Falha ao abrir/criar arquivo
    fclose(f);
    return 1;           // Sucesso
}


/*
Percorre todo o arquivo para encontrar o maior ID existente
e retorna o próximo disponível.

Essa abordagem evita reutilização de IDs já existentes.
*/
EXPORT int db_next_id() {

    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 1;   // Se não existir arquivo, primeiro ID é 1

    Aluno temp;
    int maior_id = 0;

    // Lê registro por registro
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id > maior_id)
            maior_id = temp.id;
    }

    fclose(f);

    return maior_id + 1;   // Próximo ID disponível
}


/*
Cria um novo registro no banco.
    1. Gera novo ID
    2. Define registro como ativo (matriculado = 1)
    3. Calcula situação (regra de negócio)
    4. Escreve no final do arquivo

*/
EXPORT int db_create(const Aluno *reg) {

    FILE *f = fopen(DB_FILE, "ab");   // Abre no final do arquivo
    if (!f) return 0;

    Aluno temp = *reg;   // Copia o registro recebido do Python

    temp.id = db_next_id();   // Gera ID automático
    temp.matriculado = 1;     // Marca como ativo

    /*
    Regra de negócio aplicada na camada C:
        - Frequência >= 75
        - Média >= 7.0
        => Aprovado (1)
        Caso contrário => Reprovado (0)
    */
    temp.situacao = (temp.frequencia >= 75 && temp.media >= 7.0) ? 1 : 0;

    fwrite(&temp, sizeof(Aluno), 1, f);   // Escreve no arquivo
    fclose(f);

    return 1;
}

/*
Atualiza um registro existente.
    1. Percorre o arquivo até encontrar o ID
    2. Move o cursor para trás
    3. Sobrescreve o registro
*/
EXPORT int db_update(int id, const Aluno *novo) {

    FILE *f = fopen(DB_FILE, "rb+");   // Leitura e escrita
    if (!f) return 0;

    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f)) {

        // Verifica se é o registro correto e se está ativo
        if (temp.id == id && temp.matriculado) {

            // Volta o ponteiro uma posição de struct
            fseek(f, -(long)sizeof(Aluno), SEEK_CUR);

            Aluno atualizado = *novo;
            atualizado.id = id;
            atualizado.matriculado = 1;

            // Recalcula situação
            atualizado.situacao =
                (atualizado.frequencia >= 75 && atualizado.media >= 7.0) ? 1 : 0;

            fwrite(&atualizado, sizeof(Aluno), 1, f);

            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;   // ID não encontrado
}


/*
Realiza exclusão lógica.
Ao invés de remover fisicamente do arquivo:
    Apenas define matriculado = 0
Isso evita reescrita completa do arquivo.
*/
EXPORT int db_delete(int id) {

    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f)) {

        if (temp.id == id) {

            temp.matriculado = 0;   // Marca como excluído

            fseek(f, -(long)sizeof(Aluno), SEEK_CUR);
            fwrite(&temp, sizeof(Aluno), 1, f);

            fclose(f);
            return 1;
        }
    }

    fclose(f);
    return 0;
}

/*
Remove todos os registros do banco.
Modo "wb":
    - Apaga completamente o conteúdo do arquivo
    - Cria um novo arquivo vazio
*/
EXPORT int db_delete_all(void) {

    FILE *f = fopen(DB_FILE, "wb");  // Sobrescreve completamente
    if (!f) return 0;

    fclose(f);
    return 1;
}
