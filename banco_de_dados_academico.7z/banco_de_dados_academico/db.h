#ifndef DB_H
#define DB_H

/* 
===============================================================================
    Arquivo de cabeçalho responsável por:

    • Definir constantes do banco de dados
    • Declarar a struct Aluno
    • Declarar as funções exportadas na DLL
    • Permitir integração com Python via ctypes

    Este arquivo é utilizado tanto pelo db.c quanto pelo compilador
    para gerar a biblioteca dinâmica (db.dll).
===============================================================================
*/

/* Nome do arquivo binário onde os dados são armazenados */
#define DB_FILE "database.bin"
/* Limite máximo de registros no banco */
#define MAX_REGISTROS 50
/* Tamanhos fixos para os campos texto
   (Precisam ser idênticos no Python para manter compatibilidade binária) */
#define NAME_SIZE 50
#define CPF_SIZE 12
#define MATERIA_SIZE 50

/* 
Macro para exportação das funções na DLL.
No Windows usamos __declspec(dllexport)
Em outros sistemas a macro fica vazia.
*/
#ifdef _WIN32
    #define EXPORT __declspec(dllexport)
#else
    #define EXPORT
#endif

/*
STRUCT: Aluno
Representa um registro do banco de dados.

IMPORTANTE:
A ordem e o tipo dos campos precisam ser exatamente iguais
à estrutura definida no Python (ctypes.Structure).

Qualquer alteração aqui deve ser refletida no db_service.py.
*/

typedef struct {
    int id;                         // Identificador único do aluno
    char nome[NAME_SIZE];           // Nome do aluno (string fixa)
    char cpf[CPF_SIZE];             // CPF do aluno (string fixa)
    char materias[3][MATERIA_SIZE]; // Matriz para armazenar até 3 matérias, Cada matéria possui tamanho 
    float media;                    // Média final do aluno
    int frequencia;                 // Frequência em porcentagem
    int matriculado;                // Flag de controle: 1 = Registro ativo, 0 = Registro excluído (exclusão lógica) 
    int situacao;                   // Resultado final: 1 = Aprovado, 0 = Reprovado

} Aluno;

/*
===============================================================================
PROTÓTIPOS DAS FUNÇÕES EXPORTADAS
-------------------------------------------------------------------------------
Essas funções serão compiladas na db.dll e chamadas pelo Python
através da biblioteca ctypes.
===============================================================================
*/

/* Inicializa o banco de dados (cria arquivo se não existir) */
EXPORT int db_init();
/* Retorna o próximo ID disponível */
EXPORT int db_next_id();
/* Cria um novo registro no banco */
EXPORT int db_create(const Aluno *reg);
/* Lê um registro pelo ID */
EXPORT int db_read(int id, Aluno *out);
/* Atualiza um registro existente */
EXPORT int db_update(int id, const Aluno *novo);
/* Realiza exclusão lógica de um registro */
EXPORT int db_delete(int id);
/* Remove todos os registros do banco */
EXPORT int db_delete_all(void);

#endif
