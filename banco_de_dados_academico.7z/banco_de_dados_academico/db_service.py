import ctypes
import os
import struct

# Definição dos tamanhos dos campos texto
# DEVEM ser exatamente iguais aos definidos em db.h
NAME_SIZE = 50
CPF_SIZE = 12
MATERIA_SIZE = 50


# Classe que representa a struct Aluno do C
# A ordem e os tipos precisam ser idênticos aos do db.h
class Aluno(ctypes.Structure):
    _pack_ = 1  # evita padding automático de memória
    _fields_ = [
        ("id", ctypes.c_int),
        ("nome", ctypes.c_char * NAME_SIZE),
        ("cpf", ctypes.c_char * CPF_SIZE),
        ("materias", (ctypes.c_char * MATERIA_SIZE) * 3),
        ("media", ctypes.c_float),
        ("frequencia", ctypes.c_int),
        ("matriculado", ctypes.c_int),
        ("situacao", ctypes.c_int)
    ]


class DBService:
    def __init__(self, db_name="database.bin"):
        # Nome do arquivo binário utilizado pelo sistema
        self.db_name = db_name
     
        # Carrega a DLL compilada em C
        dll_path = os.path.join(os.path.dirname(__file__), "db.dll")
        self.lib = ctypes.CDLL(dll_path)
        
        # Definição dos tipos das funções exportadas pela DLL
        self.lib.db_init.restype = ctypes.c_int

        self.lib.db_create.argtypes = [ctypes.POINTER(Aluno)]
        self.lib.db_update.argtypes = [ctypes.c_int, ctypes.POINTER(Aluno)]

        self.lib.db_create.restype = ctypes.c_int
        self.lib.db_update.restype = ctypes.c_int
        self.lib.db_delete.restype = ctypes.c_int
        self.lib.db_delete_all.restype = ctypes.c_int

        # Estrutura binária equivalente (mantida para referência)
        self.RECORD_FORMAT = '<i50s12s150sfi i i'
        self.RECORD_SIZE = struct.calcsize(self.RECORD_FORMAT)

    # Inicializa o banco (cria o arquivo se não existir)
    def init(self):
        return self.lib.db_init()

    # Lê todos os registros ativos do arquivo
    def get_todos(self, ordem="id"):
        lista = []

        if not os.path.exists(self.db_name):
            return []

        with open(self.db_name, "rb") as f:
            while True:
                data = f.read(ctypes.sizeof(Aluno))

                # Interrompe quando não houver mais registros
                if not data or len(data) < ctypes.sizeof(Aluno):
                    break
                
                # Converte os bytes do arquivo para a struct Aluno
                aluno = Aluno.from_buffer_copy(data)
                
                # Só considera registros ativos (exclusão lógica)
                if aluno.matriculado == 1:

                    # Função auxiliar para limpar campos char[] do C
                    def limpar(campo_ctypes):
                        raw = bytes(campo_ctypes)
                        texto = raw.split(b'\x00', 1)[0]
                        return texto.decode('utf-8', errors='ignore').strip()

                    # Prints usados para debug
                    print("DEBUG NOME:", repr(limpar(aluno.nome)))
                    print("DEBUG CPF:", repr(limpar(aluno.cpf)))

                    lista.append({
                        "id": aluno.id,
                        "nome": limpar(aluno.nome),
                        "cpf": limpar(aluno.cpf),
                        "materia": limpar(aluno.materias[0]),
                        "media": round(aluno.media, 1),
                        "frequencia": aluno.frequencia,
                        "situacao": "APROVADO" if aluno.situacao == 1 else "REPROVADO"
                    })
        
        # Permite ordenação dinâmica na interface
        direcao = True if ordem in ["media", "frequencia"] else False
        lista.sort(key=lambda x: x.get(ordem, x["id"]), reverse=direcao)

        return lista

    # Cria um novo aluno enviando a struct para a DLL
    def create(self, nome, cpf, media, frequencia, materia):
        
        novo = Aluno()

        # Zera a memória da struct para evitar lixo de dados
        ctypes.memset(ctypes.byref(novo), 0, ctypes.sizeof(novo))

        # Converte strings Python para bytes (formato compatível com C)
        nome_b = (nome or "").encode('utf-8')[:NAME_SIZE-1]
        cpf_b = (cpf or "").encode('utf-8')[:CPF_SIZE-1]
        mat_b = (materia or "").encode('utf-8')[:MATERIA_SIZE-1]

        # Copia os bytes para dentro da struct
        ctypes.memmove(ctypes.byref(novo, Aluno.nome.offset), nome_b, len(nome_b))
        ctypes.memmove(ctypes.byref(novo, Aluno.cpf.offset), cpf_b, len(cpf_b))
        ctypes.memmove(ctypes.byref(novo, Aluno.materias.offset), mat_b, len(mat_b))

        novo.media = float(media)
        novo.frequencia = int(frequencia)
        novo.matriculado = 1  # marca como ativo

        # Chama a função db_create da DLL
        return self.lib.db_create(ctypes.byref(novo))


    # Atualiza um registro existente
    def update(self, id_aluno, nome, cpf, media, frequencia, materia):

        aluno = Aluno()
        ctypes.memset(ctypes.byref(aluno), 0, ctypes.sizeof(aluno))

        nome_b = (nome or "").encode('utf-8')[:NAME_SIZE-1]
        cpf_b = (cpf or "").encode('utf-8')[:CPF_SIZE-1]
        mat_b = (materia or "").encode('utf-8')[:MATERIA_SIZE-1]

        ctypes.memmove(ctypes.byref(aluno, Aluno.nome.offset), nome_b, len(nome_b))
        ctypes.memmove(ctypes.byref(aluno, Aluno.cpf.offset), cpf_b, len(cpf_b))
        ctypes.memmove(ctypes.byref(aluno, Aluno.materias.offset), mat_b, len(mat_b))

        aluno.media = float(media)
        aluno.frequencia = int(frequencia)
        aluno.matriculado = 1

        # Chama a função db_update da DLL
        return self.lib.db_update(int(id_aluno), ctypes.byref(aluno))


    # Exclusão lógica de um único aluno
    def delete(self, id_aluno):
        return self.lib.db_delete(int(id_aluno))

    # Remove todos os registros do arquivo
    def delete_all(self):
        return self.lib.db_delete_all()

    # Métodos mantidos apenas para compatibilidade com a interface
    def reordenar_ids(self):
        return True
    
    def reset_ids(self):
        return 1
