import struct
import os

class DBService:
    # Definição do formato binário (id:i, nome:50s, cpf:12s, materia:50s, media:f, freq:f)
    # A estrutura deve ser idêntica ao que o Python vai ler/gravar
    RECORD_FORMAT = '<i50s12s50sff'
    RECORD_SIZE = struct.calcsize(RECORD_FORMAT)

    def __init__(self, db_name="database.bin"):
        self.db_name = db_name

    def init(self):
        """Garante a existência do arquivo binário"""
        if not os.path.exists(self.db_name):
            with open(self.db_name, 'wb') as f:
                pass
        
    def _read_all(self):
        """Método auxiliar para ler todos os registros do arquivo"""
        records = []
        if not os.path.exists(self.db_name):
            return records
            
        with open(self.db_name, 'rb') as f:
            while True:
                data = f.read(self.RECORD_SIZE)
                if not data:
                    break
                # Desempacota binário para tupla Python
                r = struct.unpack(self.RECORD_FORMAT, data)
                
                # Converte bytes para strings e cria dicionário
                records.append({
                    "id": r[0],
                    "nome": r[1].decode('utf-8').strip('\x00'),
                    "cpf": r[2].decode('utf-8').strip('\x00'),
                    "materia": r[3].decode('utf-8').strip('\x00'),
                    "media": r[4],
                    "frequencia": r[5]
                })
        return records

    def _write_all(self, records):
        """Método auxiliar para reescrever todo o arquivo"""
        with open(self.db_name, 'wb') as f:
            for r in records:
                # Empacota dados Python para binário
                data = struct.pack(
                    self.RECORD_FORMAT,
                    r['id'],
                    r['nome'].encode('utf-8')[:50],
                    r['cpf'].encode('utf-8')[:12],
                    r['materia'].encode('utf-8')[:50],
                    float(r['media']),
                    float(r['frequencia'])
                )
                f.write(data)

    def get_todos(self, ordem="id"):
        """Retorna lista de dicionários ordenada"""
        regs = self._read_all()
        
        # Ordenação
        if ordem == "nome":
            regs.sort(key=lambda x: x['nome'])
        elif ordem == "media":
            regs.sort(key=lambda x: x['media'], reverse=True)
        elif ordem == "frequencia":
            regs.sort(key=lambda x: x['frequencia'], reverse=True)
        else:
            regs.sort(key=lambda x: x['id'])
            
        return regs

    def create(self, nome, cpf, media, frequencia, materia):
        """Insere novo registro"""
        regs = self._read_all()
        
        # Gera novo ID
        new_id = max([r['id'] for r in regs], default=0) + 1
        
        new_record = {
            "id": new_id,
            "nome": nome,
            "cpf": cpf,
            "materia": materia,
            "media": media,
            "frequencia": frequencia
        }
        
        regs.append(new_record)
        self._write_all(regs)

    def update(self, id_aluno, nome, cpf, media, frequencia, materia):
        """Atualiza dados do aluno pelo ID"""
        regs = self._read_all()
        for i, r in enumerate(regs):
            if r['id'] == id_aluno:
                regs[i] = {
                    "id": id_aluno,
                    "nome": nome,
                    "cpf": cpf,
                    "materia": materia,
                    "media": media,
                    "frequencia": frequencia
                }
                break
        self._write_all(regs)

    def delete(self, id_aluno):
        """Remove registro específico"""
        regs = [r for r in self._read_all() if r['id'] != id_aluno]
        self._write_all(regs)
        return True

    def delete_all(self):
        """Limpa todos os dados da tabela"""
        self._write_all([])
        return True

    def reset_ids(self):
        """Reinicia os IDs sequencialmente"""
        regs = self._read_all()
        for i, r in enumerate(regs):
            r['id'] = i + 1
        self._write_all(regs)

    def reordenar_ids(self):
        """Sinônimo de reset_ids neste contexto"""
        self.reset_ids()
        return True