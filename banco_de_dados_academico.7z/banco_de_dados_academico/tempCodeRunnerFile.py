def _desmarcar_clique_fora(self, event):
        try:
            # Identifica se clicou em algo
            item = self.tabela.identify_row(event.y)
            if not item:
                # Se não clicou em nada, limpa a seleção
                # Usamos um try/except interno pois o selection() é quem gera o erro
                try:
                    self.tabela.selection_remove(self.tabela.selection())
                except:
                    # Se o selection() falhar por causa de null bytes, resetamos manualmente
                    self.tk.call(self.tabela._w, "selection", "set", "")
                self._limpar()
        except Exception:
            pass