import sqlite3

class DBService:
    def __init__(self, db_name="database.db"):
        self.db_name = db_name
        self.connection = None

    def init(self):
        """Inicializa banco e garante estrutura da tabela"""
        self.connection = sqlite3.connect(self.db_name)
        cursor = self.connection.cursor()
        
        # Cria tabela principal se não existir
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS alunos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                cpf TEXT,
                materia TEXT,
                media REAL,
                frequencia REAL
            )
        """)
        
        # Migração: adiciona coluna 'materia' caso a tabela seja de versão antiga
        try:
            cursor.execute("ALTER TABLE alunos ADD COLUMN materia TEXT")
        except sqlite3.OperationalError:
            pass 
            
        self.connection.commit()

    def get_todos(self, ordem="id"):
        """Retorna lista de dicionários ordenada conforme parâmetro"""
        cursor = self.connection.cursor()
        
        # Define direção: Numéricos (DESC), Texto/ID (ASC)
        coluna = "frequencia" if ordem == "frequencia" else ordem
        direcao = "DESC" if coluna in ["media", "frequencia"] else "ASC"
        
        cursor.execute(f"SELECT id, nome, cpf, materia, media, frequencia FROM alunos ORDER BY {coluna} {direcao}")
        rows = cursor.fetchall()
        
        # Formata saída para compatibilidade com o app.py
        return [
            {
                "id": r[0], 
                "nome": r[1], 
                "cpf": r[2], 
                "materia": r[3] if r[3] else "Banco de dados", 
                "media": r[4], 
                "frequencia": r[5]
            } for r in rows
        ]

    def create(self, nome, cpf, media, frequencia, materia):
        """Insere novo registro via Prepared Statement"""
        cursor = self.connection.cursor()
        cursor.execute("""
            INSERT INTO alunos (nome, cpf, media, frequencia, materia) 
            VALUES (?, ?, ?, ?, ?)
        """, (nome, cpf, media, frequencia, materia))
        self.connection.commit()

    def update(self, id_aluno, nome, cpf, media, frequencia, materia):
        """Atualiza dados do aluno pelo ID"""
        cursor = self.connection.cursor()
        cursor.execute("""
            UPDATE alunos SET nome=?, cpf=?, media=?, frequencia=?, materia=? 
            WHERE id=?
        """, (nome, cpf, media, frequencia, materia, id_aluno))
        self.connection.commit()

    def delete(self, id_aluno):
        """Remove registro específico"""
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM alunos WHERE id=?", (id_aluno,))
        self.connection.commit()
        return True

    def delete_all(self):
        """Limpa todos os dados da tabela"""
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM alunos")
        self.connection.commit()
        return True

    def reset_ids(self):
        """Zera o contador global de IDs do SQLite"""
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM sqlite_sequence WHERE name='alunos'")
        self.connection.commit()

    def reordenar_ids(self):
        """Recria a tabela para sequenciar IDs após exclusões"""
        try:
            cursor = self.connection.cursor()
            
            # Backup em memória dos dados atuais
            cursor.execute("SELECT nome, cpf, media, frequencia, materia FROM alunos ORDER BY id ASC")
            dados = cursor.fetchall()

            # Reset físico da tabela e autoincremento
            cursor.execute("DELETE FROM alunos")
            cursor.execute("DELETE FROM sqlite_sequence WHERE name='alunos'")

            # Reinserção em lote para gerar novos IDs sequenciais
            cursor.executemany("""
                INSERT INTO alunos (nome, cpf, media, frequencia, materia) 
                VALUES (?, ?, ?, ?, ?)
            """, dados)

            self.connection.commit()
            return True
        except Exception as e:
            print(f"Erro ao reordenar: {e}")
            return False