#ifndef DB_H
#define DB_H

#include <stdio.h>
#include <stdbool.h>

/* Configurações de Limites */
#define DB_FILE "database.bin"
#define NAME_SIZE 50
#define CPF_SIZE 12
#define MAX_REGISTROS 30
#define QTD_MATERIAS 3
#define MATERIA_SIZE 50
#define MATERIAS { \
    "Banco de dados", \
    "Programação de Aplicativos", \
    "Internet das Coisas(IOT)" \
}

// Representação de um registro de aluno no disco
typedef struct{  
    int id;                                     // Chave primária
    char nome[NAME_SIZE];                       // Nome completo
    char cpf[CPF_SIZE];                         // CPF (11 dígitos)
    char data_nasc[9];                          // AAAAMMDD
    float media;                                // Nota (0-10)
    int frequencia;                             // Presença (0-100)
    bool situacao;                              // True: Aprovado | False: Reprovado
    int matriculado;                            // Status: 1 (Ativo) | 0 (Inativo)
    char materias[QTD_MATERIAS][MATERIA_SIZE];  // Nomes das disciplinas
} Aluno;

/* Operações de Persistência (CRUD) */
int db_init();                                  // Inicializa arquivo binário
int db_next_id();                               // Gera novo ID sequencial
int db_create(const Aluno *reg);                // Salva novo aluno
int db_update(int id, const Aluno *novo);       // Modifica registro existente
int db_delete(int id);                          // Remoção lógica (status = 0)
int db_read(int id, Aluno *out);                // Busca por ID
int db_delete_all(void);                        // Limpa o banco de dados

/* Funções de Visualização e Ordenação */
void db_list_sorted_by_id(void);                // Ordena por ID
void db_list_sorted_by_name(void);              // Ordena Alfabeticamente
void db_list_sorted_by_freq(void);              // Ordena por Frequência
void db_list_sorted_by_grade(void);             // Ordena por Nota
void db_list_table(void);                       // Imprime tabela formatada

#endif