#include "db.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

// --- FUNÇÕES DE BANCO DE DADOS ---

// Garante a existência do arquivo binário
int db_init() {
    FILE *f = fopen(DB_FILE, "ab+");
    if (!f) return 0;
    fclose(f);
    return 1;
}

// Retorna o próximo ID incremental baseado no maior encontrado
int db_next_id() {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 1;

    Aluno temp;
    int maior_id = 0;
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id > maior_id) maior_id = temp.id;
    }
    fclose(f);
    return maior_id + 1;
}

// Salva registro e define situação acadêmica automática
int db_create(const Aluno *reg) {
    FILE *f = fopen(DB_FILE, "ab");  
    if (!f) return 0;

    Aluno temp = *reg;
    temp.situacao = (temp.frequencia >= 75 && temp.media >= 7.0);
    
    fwrite(&temp, sizeof(Aluno), 1, f);
    fclose(f);
    return 1;
}

// Busca registro físico por ID
int db_read(int id, Aluno *out) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 0;

    Aluno temp; 
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id == id) {
            *out = temp;
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Localiza via ID e sobrescreve bloco de memória no arquivo
int db_update(int id, const Aluno *novo) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Aluno temp;
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id == id && temp.matriculado) {
            fseek(f, -(long)sizeof(Aluno), SEEK_CUR); // Retrocede ponteiro para o início do registro
            Aluno atualizado = *novo;
            atualizado.id = id;
            atualizado.matriculado = 1;
            fwrite(&atualizado, sizeof(Aluno), 1, f);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Realiza exclusão lógica alterando flag de matrícula
int db_delete(int id) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Aluno temp;
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id == id) {
            temp.matriculado = 0;
            fseek(f, -(long)sizeof(Aluno), SEEK_CUR);
            fwrite(&temp, sizeof(Aluno), 1, f);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Trunca o arquivo para tamanho zero (limpeza total)
int db_delete_all(void) {
    FILE *f = fopen(DB_FILE, "wb");
    if (!f) return 0;
    fclose(f);
    return 1;
}

// --- FUNÇÕES DE LISTAGEM ---

// Exibe todos os registros sem filtros de ordenação
void db_list_table(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) {
        lista[count++] = temp;
    }
    fclose(f);

    printf("\n>>> TABELA GERAL (ATIVOS E INATIVOS)");
    renderizar_tabela(lista, count);
}

// Bubble Sort para ordenação por ID
void db_list_sorted_by_id(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) lista[count++] = temp;
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (lista[j].id > lista[j + 1].id) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> LISTA POR ID (CRESCENTE)");
    renderizar_tabela(lista, count);
}

// Bubble Sort para ordenação alfabética (strcmp)
void db_list_sorted_by_name(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.matriculado && count < MAX_REGISTROS) lista[count++] = temp;
    }
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (strcmp(lista[j].nome, lista[j + 1].nome) > 0) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> LISTA POR NOME (ALFABETICA)");
    renderizar_tabela(lista, count);
}

// Bubble Sort para ranking de frequência decrescente
void db_list_sorted_by_freq(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) lista[count++] = temp;
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (lista[j].frequencia < lista[j + 1].frequencia) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> RANKING POR FREQUENCIA (MAIOR -> MENOR)");
    renderizar_tabela(lista, count);
}

// Bubble Sort para ranking de notas decrescente
void db_list_sorted_by_grade(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) lista[count++] = temp;
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (lista[j].media < lista[j + 1].media) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> RANKING POR NOTA (MAIOR -> MENOR)");
    renderizar_tabela(lista, count);
}