import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from db_service import DBService
import pandas as pd
import os

class MiniDBStudio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema Acadêmico Pro - DB Engine")
        self.geometry("1200x800")
        
        # Definição da paleta de cores para os temas claro e escuro
        self.modo_escuro = False
        self.cores = {
            "light": {"bg": "#f0f0f0", "fg": "#000000", "entry": "#ffffff", "card": "#ffffff", "accent": "#347083", "select": "#005f73", "disabled": "#e0e0e0"},
            "dark": {"bg": "#212121", "fg": "#ffffff", "entry": "#333333", "card": "#2d2d2d", "accent": "#4da3ff", "select": "#00a8cc", "disabled": "#404040"}
        }

        self.style = ttk.Style()
        self.style.theme_use("clam")
        
        # Instanciação e inicialização do serviço de banco de dados
        self.db = DBService()
        self.db.init()
        
        self.ordem_atual = "id"
        self.lista_materias = ["Banco de dados", "Programação de Aplicativos", "Internet das Coisas(IOT)"]
        
        self._criar_layout()
        self.alternar_tema() 
        self.listar_todos()

    def formatar_cpf(self, cpf_sujo):
        """Aplica máscara visual 000.000.000-00 se o CPF tiver 11 dígitos"""
        apenas_numeros = "".join(filter(str.isdigit, str(cpf_sujo)))
        if len(apenas_numeros) == 11:
            return f"{apenas_numeros[:3]}.{apenas_numeros[3:6]}.{apenas_numeros[6:9]}-{apenas_numeros[9:]}"
        return apenas_numeros 

    # --- FUNÇÕES DE VALIDAÇÃO ---

    def _validar_cpf_input(self, P):
        """Bloqueia caracteres não numéricos e limita a 11 dígitos no input"""
        return (P.isdigit() or P == "") and len(P) <= 11

    def _validar_nota_freq(self, P):
        """Garante que a entrada seja numérica e esteja entre 0 e 100"""
        if P == "": return True
        try:
            v = float(P)
            return 0 <= v <= 100
        except: return False

    def _criar_layout(self):
        """Montagem da interface gráfica dividida por frames"""
        top_bar = ttk.Frame(self)
        top_bar.pack(fill=tk.X, padx=15, pady=10)
        
        # Seção de busca e filtros de situação acadêmica
        search_frame = ttk.LabelFrame(top_bar, text=" Filtros de Busca ")
        search_frame.pack(side=tk.LEFT, padx=(0, 10))
        self.search_var = tk.StringVar()
        self.search_var.trace_add("write", lambda *args: self.listar_todos())
        ttk.Entry(search_frame, textvariable=self.search_var, width=15).pack(side=tk.LEFT, padx=5, pady=5)
        self.filter_sit = ttk.Combobox(search_frame, values=["Todos", "Aprovados", "Reprovados"], width=10, state="readonly")
        self.filter_sit.set("Todos")
        self.filter_sit.pack(side=tk.LEFT, padx=5)
        self.filter_sit.bind("<<ComboboxSelected>>", lambda e: self.listar_todos())

        # Botões para manipulação de arquivos externos
        files_frame = ttk.LabelFrame(top_bar, text=" Operações com Arquivos ")
        files_frame.pack(side=tk.LEFT, padx=5)
        
        f_imp = ttk.Frame(files_frame)
        f_imp.pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(f_imp, text="📥 Importar TXT", command=self.importar_txt, width=15).pack(pady=2)
        ttk.Button(f_imp, text="📥 Importar Excel", command=self.importar_excel, width=15).pack(pady=2)

        f_exp = ttk.Frame(files_frame)
        f_exp.pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(f_exp, text="📤 Exportar TXT", command=self.exportar_txt, width=15).pack(pady=2)
        ttk.Button(f_exp, text="📊 Exportar Excel", command=self.exportar_excel, width=15).pack(pady=2)

        # Dashboard de estatísticas e controle de tema
        side_panel = ttk.Frame(top_bar)
        side_panel.pack(side=tk.RIGHT)

        try:
            dir_script = os.path.dirname(os.path.abspath(__file__))
            path_logo = os.path.join(dir_script, "garoto_propaganda.png")
            self.logo_img = tk.PhotoImage(file=path_logo).subsample(8, 8) 
            self.lbl_logo = tk.Label(side_panel, image=self.logo_img)
            self.lbl_logo.pack(side=tk.LEFT, padx=5)
        except: pass

        self.btn_tema = tk.Button(side_panel, text="🌙", command=self.alternar_tema, width=4, relief="groove")
        self.btn_tema.pack(side=tk.RIGHT, padx=5)
        
        self.stats_frame = ttk.LabelFrame(side_panel, text=" Status da Turma ")
        self.stats_frame.pack(side=tk.RIGHT, padx=5)
        self.lbl_stats = ttk.Label(self.stats_frame, text="...", font=("Segoe UI", 9, "bold"), justify="center")
        self.lbl_stats.pack(padx=10, pady=5)

        # Barra de botões para alteração da ordenação SQL
        toolbar = ttk.Frame(self)
        toolbar.pack(fill=tk.X, padx=15, pady=5)
        ttk.Label(toolbar, text="Ordenar Lista por:", font=("Segoe UI", 8, "bold")).pack(side=tk.LEFT, padx=5)
        
        botoes_ordem = [("ID", "id"), ("Nome", "nome"), ("Matéria", "materia"), ("Nota", "media"), ("Freq", "frequencia"), ("Situação", "situacao")]
        for lb, ct in botoes_ordem:
            ttk.Button(toolbar, text=lb, width=9, command=lambda c=ct: self.reordenar(c)).pack(side=tk.LEFT, padx=2)

        # Área de entrada para cadastro/edição de alunos
        container = ttk.Frame(self)
        container.pack(fill=tk.BOTH, expand=True, padx=15, pady=5)

        form = ttk.LabelFrame(container, text=" Formulário de Cadastro ")
        form.pack(fill=tk.X, pady=(0, 10), ipady=5)
        
        for i, h in enumerate(["ID", "Nome Completo", "CPF (11 dígitos)", "Matéria", "Média (0-100)", "Freq %"]):
            ttk.Label(form, text=h, font=("Segoe UI", 8, "bold")).grid(row=0, column=i, padx=5, sticky="w")

        v_num = (self.register(self._validar_nota_freq), '%P')
        v_cpf = (self.register(self._validar_cpf_input), '%P')

        self.ent_id = ttk.Entry(form, width=6, state="readonly", style="Id.TEntry")
        self.ent_id.grid(row=1, column=0, padx=5, pady=5)
        self.ent_nome = ttk.Entry(form, width=25)
        self.ent_nome.grid(row=1, column=1, padx=5)
        self.ent_cpf = ttk.Entry(form, width=15, validate="key", validatecommand=v_cpf)
        self.ent_cpf.grid(row=1, column=2, padx=5)
        self.ent_materia = ttk.Combobox(form, values=self.lista_materias, width=22, state="readonly")
        self.ent_materia.set(self.lista_materias[0])
        self.ent_materia.grid(row=1, column=3, padx=5)
        self.ent_media = ttk.Entry(form, width=10, validate="key", validatecommand=v_num)
        self.ent_media.grid(row=1, column=4, padx=5)
        self.ent_freq = ttk.Entry(form, width=10, validate="key", validatecommand=v_num)
        self.ent_freq.grid(row=1, column=5, padx=5)

        # Botões de CRUD (Salvar, Limpar, Excluir)
        btn_action = ttk.Frame(container)
        btn_action.pack(fill=tk.X, pady=(0, 10))
        ttk.Button(btn_action, text="✚ Novo / Limpar", command=self._limpar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_action, text="💾 SALVAR", command=self.salvar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_action, text="🔥 EXCLUIR TUDO", command=self.excluir_todos).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_action, text="🗑 DELETAR", command=self.excluir).pack(side=tk.RIGHT, padx=5)

        # Configuração da Treeview (Tabela de dados)
        cols = ("id", "nome", "cpf", "materia", "media", "freq", "situacao")
        self.tabela = ttk.Treeview(container, columns=cols, show="headings")
        h_tab = ["ID", "NOME", "CPF", "MATÉRIA", "NOTA", "FREQ %", "SITUAÇÃO"]
        for c, h in zip(cols, h_tab):
            self.tabela.heading(c, text=h)
            self.tabela.column(c, width=80, anchor="center")
        self.tabela.column("nome", width=220, anchor="w")
        self.tabela.column("materia", width=180, anchor="center")
        self.tabela.pack(fill=tk.BOTH, expand=True)
        
        self.tabela.bind("<<TreeviewSelect>>", self.carregar_selecionado)
        self.tabela.bind("<Button-1>", self._desmarcar_clique_fora)

    def _desmarcar_clique_fora(self, event):
        try:
            # Identifica se clicou em algo
            item = self.tabela.identify_row(event.y)
            if not item:
                # Se não clicou em nada, limpa a seleção
                try:
                    self.tabela.selection_remove(self.tabela.selection())
                except:
                    self.tk.call(self.tabela._w, "selection", "set", "")
                self._limpar()
        except Exception:
            pass

    def alternar_tema(self):
        """Troca as cores de fundo e foreground baseada no dicionário self.cores"""
        self.modo_escuro = not self.modo_escuro
        t = self.cores["light"] if self.modo_escuro else self.cores["dark"]
        self.configure(bg=t["bg"])
        if hasattr(self, 'lbl_logo'): self.lbl_logo.config(bg=t["bg"])
        self.style.configure("Id.TEntry", fieldbackground=t["disabled"])
        self.style.configure("TFrame", background=t["bg"])
        self.style.configure("TLabelframe", background=t["bg"], foreground=t["fg"])
        self.style.configure("TLabel", background=t["bg"], foreground=t["fg"])
        self.style.configure("Treeview", background=t["card"], foreground=t["fg"], fieldbackground=t["card"])
        self.tabela.tag_configure('aprovado', foreground='#2e7d32' if self.modo_escuro else '#81c784')
        self.tabela.tag_configure('reprovado', foreground='#d32f2f' if self.modo_escuro else '#e57373')
        self.btn_tema.config(text="☀️" if self.modo_escuro else "🌙", bg=t["card"], fg=t["fg"])

    def listar_todos(self):
        """Atualiza a Treeview com dados do DB e aplica filtros de busca/situação"""
        for i in self.tabela.get_children(): self.tabela.delete(i)
        
        if self.ordem_atual == "situacao":
            regs = self.db.get_todos("id")
            regs.sort(key=lambda x: (x["media"] >= 7.0 and x["frequencia"] >= 75), reverse=True)
        else:
            regs = self.db.get_todos(self.ordem_atual)

        total, soma, aprov = 0, 0, 0
        busca = self.search_var.get().lower()
        f_sit = self.filter_sit.get()

        for a in regs:
            is_ap = a["media"] >= 70.0 and a["frequencia"] >= 75
            txt_sit = "APROVADO" if is_ap else "REPROVADO"
            if (f_sit == "Aprovados" and not is_ap) or (f_sit == "Reprovados" and is_ap): continue
            if busca in a["nome"].lower() or busca in a["cpf"]:
                self.tabela.insert("", "end", values=(
                    a["id"], a["nome"], self.formatar_cpf(a["cpf"]), a["materia"],
                    f"{a['media']:.1f}", f"{int(a['frequencia'])}%", txt_sit
                ), tags=('aprovado' if is_ap else 'reprovado',))
                total += 1; soma += a["media"]
                if is_ap: aprov += 1
        
        m_geral = (soma/total) if total > 0 else 0
        p_aprov = (aprov/total*100) if total > 0 else 0
        self.lbl_stats.config(text=f"Total: {total} | Méd: {m_geral:.1f} | Aprov: {p_aprov:.0f}%")

    def salvar(self):
        """Valida campos e chama o serviço para criar ou atualizar registro"""
        try:
            id_s = self.ent_id.get()
            n = str(self.ent_nome.get()).upper().strip()
            c = "".join(filter(str.isdigit, str(self.ent_cpf.get())))
            mat = str(self.ent_materia.get())
    
            try:
                m = float(self.ent_media.get())
                f = int(float(self.ent_freq.get()))
            except ValueError:
                return messagebox.showwarning("Erro", "Média e Frequência devem ser números.")

            if not n or len(c) < 11: 
                return messagebox.showwarning("Aviso", "Nome e CPF (11 dígitos) são obrigatórios.")
            
            if not id_s: 
                self.db.create(n, c, m, f, mat)
            else: 
                self.db.update(int(id_s), n, c, m, f, mat)
            
            self._limpar()
            self.listar_todos()
        except Exception as e: 
            messagebox.showerror("Erro ao Salvar", f"Detalhes: {e}")

    def carregar_selecionado(self, e):
        """Lê os dados da tabela com segurança máxima"""
        try:
            sel = self.tabela.selection()
            if not sel: return
            
            v = self.tabela.item(sel[0], "values")
            v = [str(x).replace('\x00', '').strip() for x in v]
            

            self.ent_id.config(state="normal")
            self.ent_id.delete(0, tk.END); self.ent_id.insert(0, v[0])
            self.ent_id.config(state="readonly")
            self.ent_nome.delete(0, tk.END); self.ent_nome.insert(0, v[1])
            self.ent_cpf.delete(0, tk.END); self.ent_cpf.insert(0, v[2].replace('.','').replace('-',''))
            self.ent_materia.set(v[3])
            self.ent_media.delete(0, tk.END); self.ent_media.insert(0, v[4])
            self.ent_freq.delete(0, tk.END); self.ent_freq.insert(0, v[5].replace('%',''))
        except Exception as err:
            print(f"Erro ao carregar campos: {err}")

    def _limpar(self):
        """Reseta todos os widgets do formulário para o estado inicial"""
        self.ent_id.config(state="normal")
        for e in [self.ent_id, self.ent_nome, self.ent_cpf, self.ent_media, self.ent_freq]: e.delete(0, tk.END)
        self.ent_id.config(state="readonly"); self.ent_materia.set(self.lista_materias[0])

    def excluir(self):
        """Remove registro selecionado"""
        id_s = self.ent_id.get()
        if id_s and messagebox.askyesno("Confirmar", "Deletar registro?"):
            self.db.delete(int(id_s)); self.db.reordenar_ids(); self._limpar(); self.listar_todos()

    def excluir_todos(self):
        """Apaga todos os registros e reinicia o contador"""
        if messagebox.askyesno("Atenção", "Apagar TUDO?"):
            self.db.delete_all(); self.db.reset_ids(); self._limpar(); self.listar_todos()

    def reordenar(self, c): 
        """Define a coluna de ordenação e atualiza a exibição"""
        self.ordem_atual = c
        self.listar_todos()

    def importar_txt(self):
        """Parse de arquivo TXT para importação em lote"""
        p = filedialog.askopenfilename(filetypes=[("Texto", "*.txt")])
        if not p: return
        try:
            with open(p, "r", encoding="utf-8") as f:
                for l in f:
                    d = [i.strip() for i in l.split(",")]
                    if len(d) >= 5:
                        # d[1]=nome, d[2]=cpf, d[3]=materia, d[4]=nota, d[5]=freq
                        nome = str(d[1])
                        cpf = "".join(filter(str.isdigit, str(d[2])))
                        materia = str(d[3])
                        nota = float(d[4])
                        freq = int(float(d[5].replace('%','')))
                        
                        self.db.create(nome, cpf, nota, freq, materia)
            self.db.reordenar_ids()
            self.listar_todos()
        except Exception as e: 
            messagebox.showerror("Erro TXT", f"Erro na linha: {e}")

    def importar_excel(self):
        """Usa Pandas para ler arquivo Excel e popular o banco de dados"""
        p = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx")])
        if not p: return
        try:
            df = pd.read_excel(p)
            df.columns = [c.strip().lower() for c in df.columns]
            for _, r in df.iterrows():
                # Conversão explícita para tipos Python nativos (evita erro de ctypes)
                nome = str(r.get('nome','')).strip()
                cpf = "".join(filter(str.isdigit, str(r.get('cpf',''))))
                materia = str(r.get('matéria', r.get('materia','')))
                
                # Tratamento de nota e freq vindos do Excel
                nota_bruta = str(r.get('nota', r.get('média', 0))).replace('%','')
                freq_bruta = str(r.get('freq', r.get('frequência', 0))).replace('%','')
                
                nota = float(nota_bruta)
                freq = int(float(freq_bruta))
                
                if nome and len(cpf) >= 11:
                    self.db.create(nome, cpf, nota, freq, materia)
            
            self.db.reordenar_ids()
            self.listar_todos()
            messagebox.showinfo("Sucesso", "Excel Importado!")
        except Exception as e: 
            messagebox.showerror("Erro Excel", f"Erro: {e}")

    def exportar_excel(self):
        """Gera arquivo .xlsx a partir dos dados visíveis na Treeview"""
        p = filedialog.asksaveasfilename(defaultextension=".xlsx")
        if p:
            d = [self.tabela.item(i)["values"] for i in self.tabela.get_children()]
            pd.DataFrame(d, columns=["ID", "Nome", "CPF", "Materia", "Nota", "Freq", "Sit"]).to_excel(p, index=False)

    def exportar_txt(self):
        """Salva registros em texto puro com campos separados por vírgula"""
        p = filedialog.asksaveasfilename(defaultextension=".txt")
        if p:
            with open(p, "w", encoding="utf-8") as f:
                for i in self.tabela.get_children():
                    f.write(", ".join(map(str, self.tabela.item(i)["values"])) + "\n")

if __name__ == "__main__":
    app = MiniDBStudio()
    app.mainloop()