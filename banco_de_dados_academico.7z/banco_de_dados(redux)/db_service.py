import sqlite3

class DBService:
    def __init__(self, db_name="database.db"):
        self.db_name = db_name
        self.connection = None

    def init(self):
        self.connection = sqlite3.connect(self.db_name)
        cursor = self.connection.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS alunos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                cpf TEXT,
                media REAL,
                frequencia REAL
            )
        """)
        self.connection.commit()

    def get_todos(self, ordem="id"):
        cursor = self.connection.cursor()
        
        # Mapeia 'frequencia' caso venha da interface como 'freq'
        coluna = "frequencia" if ordem == "frequencia" else ordem
        
        # Define a direção: 
        # Se for nota (media) ou frequencia, queremos do maior para o menor (DESC)
        # Se for nome ou ID, mantemos do menor para o maior (ASC)
        direcao = "DESC" if coluna in ["media", "frequencia"] else "ASC"
        
        cursor.execute(f"SELECT * FROM alunos ORDER BY {coluna} {direcao}")
        rows = cursor.fetchall()
        return [{"id": r[0], "nome": r[1], "cpf": r[2], "media": r[3], "frequencia": r[4]} for r in rows]

    def create(self, nome, cpf, media, frequencia):
        cursor = self.connection.cursor()
        cursor.execute("INSERT INTO alunos (nome, cpf, media, frequencia) VALUES (?, ?, ?, ?)",
                       (nome, cpf, media, frequencia))
        self.connection.commit()

    def update(self, id_aluno, nome, cpf, media, frequencia):
        cursor = self.connection.cursor()
        cursor.execute("UPDATE alunos SET nome=?, cpf=?, media=?, frequencia=? WHERE id=?",
                       (nome, cpf, media, frequencia, id_aluno))
        self.connection.commit()

    def delete(self, id_aluno):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM alunos WHERE id=?", (id_aluno,))
        self.connection.commit()
        return True

    def delete_all(self):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM alunos")
        self.connection.commit()
        return True

    def reset_ids(self):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM sqlite_sequence WHERE name='alunos'")
        self.connection.commit()

    def reordenar_ids(self):
        """Reorganiza os IDs para que fiquem sequenciais (1, 2, 3...)"""
        try:
            cursor = self.connection.cursor()
            # 1. Pegamos todos os dados atuais ordenados pelo ID antigo
            cursor.execute("SELECT nome, cpf, media, frequencia FROM alunos ORDER BY id ASC")
            dados = cursor.fetchall()

            # 2. Limpamos a tabela e resetamos o contador de AUTOINCREMENT
            cursor.execute("DELETE FROM alunos")
            cursor.execute("DELETE FROM sqlite_sequence WHERE name='alunos'")

            # 3. Reinserimos os dados (o ID será gerado automaticamente de 1 em diante)
            cursor.executemany("""
                INSERT INTO alunos (nome, cpf, media, frequencia) 
                VALUES (?, ?, ?, ?)
            """, dados)

            self.connection.commit()
            return True
        except Exception as e:
            print(f"Erro ao reordenar: {e}")
            return False