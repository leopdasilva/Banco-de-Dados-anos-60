import tkinter as tk
from tkinter import ttk, messagebox, filedialog
from db_service import DBService
import pandas as pd

class MiniDBStudio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema Acadêmico Pro - DB Engine")
        self.geometry("1100x750")
        
        self.modo_escuro = False
        self.cores = {
            "light": {"bg": "#f0f0f0", "fg": "#000000", "entry": "#ffffff", "card": "#ffffff", "accent": "#347083", "select": "#005f73", "disabled": "#e0e0e0"},
            "dark": {"bg": "#212121", "fg": "#ffffff", "entry": "#333333", "card": "#2d2d2d", "accent": "#4da3ff", "select": "#00a8cc", "disabled": "#404040"}
        }

        self.style = ttk.Style()
        self.style.theme_use("clam")
        
        self.db = DBService()
        self.db.init()
        
        self.ordem_atual = "id"
        self._criar_layout()
        self.alternar_tema() 
        self.listar_todos()

    def formatar_cpf(self, cpf_sujo):
        apenas_numeros = "".join(filter(str.isdigit, str(cpf_sujo)))
        if len(apenas_numeros) == 11:
            return f"{apenas_numeros[:3]}.{apenas_numeros[3:6]}.{apenas_numeros[6:9]}-{apenas_numeros[9:]}"
        return apenas_numeros 

    # --- FUNÇÕES DE VALIDAÇÃO ---
    def _validar_nome(self, P):
        return len(P) <= 50

    def _validar_cpf(self, P):
        return len(P) <= 11 and (P == "" or P.isdigit())

    def _validar_nota_freq(self, P):
        if P == "": return True
        try:
            valor = float(P)
            return 0 <= valor <= 100
        except ValueError:
            return False

    def alternar_tema(self):
        self.modo_escuro = not self.modo_escuro
        tema = self.cores["dark"] if self.modo_escuro else self.cores["light"]
        self.configure(bg=tema["bg"])
        
        # Estilo customizado para o campo ID "apagado"
        self.style.configure("Id.TEntry", fieldbackground=tema["disabled"], foreground="#888888")
        
        self.style.configure("TFrame", background=tema["bg"])
        self.style.configure("TLabelframe", background=tema["bg"], foreground=tema["fg"])
        self.style.configure("TLabelframe.Label", background=tema["bg"], foreground=tema["fg"])
        self.style.configure("TLabel", background=tema["bg"], foreground=tema["fg"])
        self.style.configure("Treeview", background=tema["card"], foreground=tema["fg"], fieldbackground=tema["card"], rowheight=38, font=("Segoe UI", 10))
        self.style.map("Treeview", background=[('selected', tema["select"])], foreground=[('selected', '#ffffff')])
        
        if self.modo_escuro:
            self.tabela.tag_configure('aprovado', foreground='#81c784')
            self.tabela.tag_configure('reprovado', foreground='#e57373')
        else:
            self.tabela.tag_configure('aprovado', foreground='#2e7d32')
            self.tabela.tag_configure('reprovado', foreground='#d32f2f')
        
        self.btn_tema.config(text="☀️ Modo Dia" if self.modo_escuro else "🌙 Modo Noite", bg=tema["card"], fg=tema["fg"])

    def _criar_layout(self):
        # ... (código da top_bar e toolbar permanecem iguais)
        top_bar = ttk.Frame(self); top_bar.pack(fill=tk.X, padx=15, pady=10)
        search_frame = ttk.LabelFrame(top_bar, text=" Filtros de Visualização "); search_frame.pack(side=tk.LEFT, fill=tk.Y)
        self.search_var = tk.StringVar(); self.search_var.trace_add("write", lambda *args: self.listar_todos())
        ttk.Entry(search_frame, textvariable=self.search_var, width=25).pack(side=tk.LEFT, padx=10, pady=5)
        self.filter_sit = ttk.Combobox(search_frame, values=["Todos", "Aprovados", "Reprovados"], width=12, state="readonly"); self.filter_sit.set("Todos"); self.filter_sit.pack(side=tk.LEFT, padx=5); self.filter_sit.bind("<<ComboboxSelected>>", lambda e: self.listar_todos())
        side_panel = ttk.Frame(top_bar); side_panel.pack(side=tk.RIGHT, fill=tk.Y)
        self.btn_tema = tk.Button(side_panel, text="🌙 Modo Noite", command=self.alternar_tema, relief="groove", cursor="hand2"); self.btn_tema.pack(side=tk.TOP, fill=tk.X, pady=(0, 5))
        self.stats_frame = ttk.LabelFrame(side_panel, text=" Dashboard Turma "); self.stats_frame.pack(side=tk.TOP, fill=tk.BOTH)
        self.lbl_stats = ttk.Label(self.stats_frame, text="Calculando...", font=("Segoe UI", 10, "bold")); self.lbl_stats.pack(padx=15, pady=5)
        toolbar = ttk.Frame(self); toolbar.pack(fill=tk.X, padx=15)
        btns = [("ID", "id"), ("Nome", "nome"), ("Nota", "media"), ("Freq", "frequencia")]
        for label, crit in btns: ttk.Button(toolbar, text=label, width=8, command=lambda c=crit: self.reordenar(c)).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, padx=15, fill=tk.Y)
        ttk.Button(toolbar, text="📤 Exp. TXT", command=self.exportar_txt).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="📊 Exp. Excel", command=self.exportar_excel).pack(side=tk.LEFT, padx=2)
        ttk.Separator(toolbar, orient=tk.VERTICAL).pack(side=tk.LEFT, padx=15, fill=tk.Y)
        ttk.Button(toolbar, text="📥 Imp. TXT", command=self.importar_txt).pack(side=tk.LEFT, padx=2)
        ttk.Button(toolbar, text="📥 Imp. Excel", command=self.importar_excel).pack(side=tk.LEFT, padx=2)

        container = ttk.Frame(self)
        container.pack(fill=tk.BOTH, expand=True, padx=15, pady=10)

        form = ttk.LabelFrame(container, text=" Formulário de Gestão (Validação Ativa) ")
        form.pack(fill=tk.X, pady=(0, 10), ipady=5)
        
        # Registrando validações
        v_nome = (self.register(self._validar_nome), '%P')
        v_cpf = (self.register(self._validar_cpf), '%P')
        v_num = (self.register(self._validar_nota_freq), '%P')

        headers_form = ["ID", "Nome (Máx 50)", "CPF (11 dígitos)", "Média (0-100)", "Frequência %"]
        for i, h in enumerate(headers_form):
            ttk.Label(form, text=h, font=("Segoe UI", 8, "bold")).grid(row=0, column=i, padx=5, sticky="w")

        self.ent_id = ttk.Entry(form, width=8, state="readonly", style="Id.TEntry", font=("Consolas", 10, "bold"))
        self.ent_id.grid(row=1, column=0, padx=5, pady=5)
        
        self.ent_nome = ttk.Entry(form, width=30, validate="key", validatecommand=v_nome)
        self.ent_nome.grid(row=1, column=1, padx=5)
        
        self.ent_cpf = ttk.Entry(form, width=18, validate="key", validatecommand=v_cpf)
        self.ent_cpf.grid(row=1, column=2, padx=5)
        
        self.ent_media = ttk.Entry(form, width=10, validate="key", validatecommand=v_num)
        self.ent_media.grid(row=1, column=3, padx=5)
        
        self.ent_freq = ttk.Entry(form, width=10, validate="key", validatecommand=v_num)
        self.ent_freq.grid(row=1, column=4, padx=5)

        # ... (resto do layout dos botões e Treeview permanece o mesmo)
        btn_frame = ttk.Frame(container); btn_frame.pack(fill=tk.X, pady=(0, 10))
        ttk.Button(btn_frame, text="✚ Novo / Limpar", command=self._limpar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="💾 SALVAR", command=self.salvar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="🔥 LIMPAR TUDO", command=self.excluir_todos).pack(side=tk.RIGHT, padx=5)
        ttk.Button(btn_frame, text="🗑 DELETAR", command=self.excluir).pack(side=tk.RIGHT, padx=5)
        cols = ("id", "nome", "cpf", "media", "freq", "situacao"); self.tabela = ttk.Treeview(container, columns=cols, show="headings")
        map_db = {"id":"id", "nome":"nome", "cpf":"cpf", "media":"media", "freq":"frequencia", "situacao":"media"}
        headers_tab = ["ID", "NOME COMPLETO", "CPF", "NOTA", "FREQ %", "SITUAÇÃO"]
        for c, h in zip(cols, headers_tab):
            self.tabela.heading(c, text=h, command=lambda _c=c: self.reordenar(map_db[_c]))
            self.tabela.column(c, width=100, anchor="center")
        self.tabela.column("nome", width=300, anchor="w"); self.tabela.pack(fill=tk.BOTH, expand=True)
        self.tabela.bind("<<TreeviewSelect>>", self.carregar_selecionado); self.bind("<Button-1>", self.clicar_fora)

    def listar_todos(self):
        for i in self.tabela.get_children(): self.tabela.delete(i)
        registros = self.db.get_todos(self.ordem_atual)
        total, soma_notas, aprovados = 0, 0, 0
        busca = self.search_var.get().lower()
        filtro_sit = self.filter_sit.get()

        for a in registros:
            # Aqui a nota já vem como float (ex: 8.5)
            is_aprov = a["media"] >= 7.0 and a["frequencia"] >= 75
            sit_texto = "APROVADO" if is_aprov else "REPROVADO"
            if filtro_sit == "Aprovados" and not is_aprov: continue
            if filtro_sit == "Reprovados" and is_aprov: continue
            if busca in a["nome"].lower() or busca in a["cpf"]:
                tag = 'aprovado' if is_aprov else 'reprovado'
                self.tabela.insert("", "end", values=(a["id"], a["nome"], self.formatar_cpf(a["cpf"]), f"{a['media']:.1f}", f"{int(a['frequencia'])}%", sit_texto), tags=(tag,))
                total += 1
                soma_notas += a["media"]
                if is_aprov: aprovados += 1
        
        res_media = (soma_notas/total) if total > 0 else 0
        res_aprov = (aprovados/total*100) if total > 0 else 0
        self.lbl_stats.config(text=f"Total: {total} | Méd: {res_media:.1f} | Aprov: {res_aprov:.0f}%")

    def salvar(self):
        try:
            id_s = self.ent_id.get()
            n = self.ent_nome.get()
            c = "".join(filter(str.isdigit, self.ent_cpf.get()))
            # CONVERSÃO: Usuário digita 85, salvamos 8.5
            m = float(self.ent_media.get()) / 10.0
            f = float(self.ent_freq.get())
            
            if not n or len(c) < 11:
                messagebox.showwarning("Aviso", "Nome e CPF (11 dígitos) são obrigatórios.")
                return

            if not id_s: 
                self.db.create(n, c, m, f)
                self.db.reordenar_ids()
            else: 
                self.db.update(int(id_s), n, c, m, f)
            
            self._limpar(); self.listar_todos()
        except ValueError: 
            messagebox.showerror("Erro", "Preencha Média e Frequência com números de 0 a 100.")

    def carregar_selecionado(self, event):
        item = self.tabela.selection()
        if not item: return
        val = self.tabela.item(item, "values")
        self.ent_id.config(state="normal")
        self.ent_id.delete(0, tk.END); self.ent_id.insert(0, val[0])
        self.ent_id.config(state="readonly")
        
        self.ent_nome.delete(0, tk.END); self.ent_nome.insert(0, val[1])
        self.ent_cpf.delete(0, tk.END); self.ent_cpf.insert(0, "".join(filter(str.isdigit, val[2])))
        
        # CONVERSÃO VOLTA: 8.5 na tabela vira 85 no campo de edição
        nota_edit = int(float(val[3]) * 10)
        self.ent_media.delete(0, tk.END); self.ent_media.insert(0, str(nota_edit))
        
        self.ent_freq.delete(0, tk.END); self.ent_freq.insert(0, val[4].replace('%',''))

    def _limpar(self):
        self.ent_id.config(state="normal")
        for e in [self.ent_id, self.ent_nome, self.ent_cpf, self.ent_media, self.ent_freq]: e.delete(0, tk.END)
        self.ent_id.config(state="readonly")
        self.tabela.selection_remove(self.tabela.selection())

    # ... (os métodos de exportar/importar e excluir permanecem os mesmos)
    def excluir(self):
        id_s = self.ent_id.get()
        if id_s and messagebox.askyesno("Deletar", "Confirmar exclusão?"):
            if self.db.delete(int(id_s)):
                self.db.reordenar_ids()
                if not self.db.get_todos(): self.db.reset_ids()
                self._limpar(); self.listar_todos()

    def excluir_todos(self):
        if messagebox.askyesno("Confirmação", "Apagar tudo e resetar IDs?"):
            if self.db.delete_all():
                self.db.reset_ids()
                self._limpar(); self.listar_todos()

    def reordenar(self, criterial):
        self.ordem_atual = criterial
        self.listar_todos()

    def clicar_fora(self, event):
        if event.widget == self or isinstance(event.widget, ttk.Frame): self._limpar()

    def importar_txt(self):
        path = filedialog.askopenfilename(filetypes=[("Arquivos de Texto", "*.txt")])
        if not path: return
        try:
            with open(path, "r", encoding="utf-8") as f:
                for linha in f:
                    linha = linha.strip()
                    if not linha: continue
                    proc = linha.replace("(", "").replace(")", "").replace("'", "")
                    d = [i.strip() for i in proc.split(",")]
                    # Note que na importação, se o TXT já tiver a nota como 8.5, ele mantém. 
                    # Se for importar valor cheio, precisaria dividir por 10 aqui também.
                    self.db.create(d[1], d[2], float(d[3]), float(str(d[4]).replace('%','')))
            self.db.reordenar_ids()
            self.listar_todos()
            messagebox.showinfo("Sucesso", "Importação TXT concluída!")
        except Exception as e: messagebox.showerror("Erro", f"Falha no TXT: {e}")

    def importar_excel(self):
        path = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx")])
        if not path: return
        try:
            df = pd.read_excel(path)
            df.columns = [str(c).strip().lower() for c in df.columns]
            c_n = next((c for c in df.columns if c in ['nome', 'aluno']), None)
            c_c = next((c for c in df.columns if c in ['cpf']), None)
            c_m = next((c for c in df.columns if c in ['media', 'média', 'nota']), None)
            c_f = next((c for c in df.columns if c in ['freq', 'frequência', 'frequencia']), None)
            for _, r in df.iterrows():
                self.db.create(str(r[c_n]), str(r[c_c]), float(r[c_m]), float(str(r[c_f]).replace('%','')))
            self.db.reordenar_ids()
            self.listar_todos()
            messagebox.showinfo("Sucesso", "Importação Excel concluída!")
        except Exception as e: messagebox.showerror("Erro", f"Falha no Excel: {e}")

    def exportar_txt(self):
        path = filedialog.asksaveasfilename(defaultextension=".txt")
        if path:
            with open(path, "w", encoding="utf-8") as f:
                for i in self.tabela.get_children(): f.write(str(self.tabela.item(i)["values"]) + "\n")

    def exportar_excel(self):
        path = filedialog.asksaveasfilename(defaultextension=".xlsx")
        if path:
            dados = [self.tabela.item(i)["values"] for i in self.tabela.get_children()]
            pd.DataFrame(dados, columns=["ID", "Nome", "CPF", "Nota", "Freq", "Situacao"]).to_excel(path, index=False)

if __name__ == "__main__":
    app = MiniDBStudio()
    app.mainloop()