#include "db.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>

// --- FUNÇÃO DE INTERFACE (INTERNA) ---
// Formata e imprime uma tabela de alunos no terminal
void renderizar_tabela(Aluno *lista, int count) {
    printf("\n%-4s | %-18.18s | %-12s | %-4s | %-4s | %-8s | %-8s\n", 
           "ID", "NOME", "CPF", "MED", "FREQ", "SITUACAO", "STATUS");
    printf("-------------------------------------------------------------------------------------\n");

    for (int i = 0; i < count; i++) {
        bool aprovado = (lista[i].media >= 7.0 && lista[i].frequencia >= 75);
        printf("%-4d | %-18.18s | %-12s | %-4.1f | %-3d%% | %-8s | %-8s\n",
               lista[i].id, 
               lista[i].nome, 
               lista[i].cpf, 
               lista[i].media, 
               lista[i].frequencia,
               aprovado ? "APROV" : "REPROV",
               lista[i].matriculado ? "ATIVO" : "INATIVO");
    }
    printf("-------------------------------------------------------------------------------------\n");
    printf("Total de registros processados: %d\n", count);
}

// --- FUNÇÕES DE BANCO DE DADOS ---

// Função para criar um arquivo binário caso ele não exista, se ele existir, ele abre e fecha, mantendo os dados intactos 
int db_init() {
    FILE *f = fopen(DB_FILE, "ab+");
    if (!f) return 0;
    fclose(f);
    return 1;
}

// Função para varrer o arquivo para encontrar o maior ID atual e retorna o próximo valor disponível (autoincremento)
int db_next_id() {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 1;

    Aluno temp;
    int maior_id = 0;
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id > maior_id) maior_id = temp.id;
    }
    fclose(f);
    return maior_id + 1;
}

// Função para gravar um novo registro de aluno no final do arquivo binário
int db_create(const Aluno *reg) {
    FILE *f = fopen(DB_FILE, "ab");  
    if (!f) return 0;

    Aluno temp = *reg;
    temp.situacao = (temp.frequencia >= 75 && temp.media >= 7.0);
    
    fwrite(&temp, sizeof(Aluno), 1, f);
    fclose(f);
    return 1;
}

// Função para buscar um aluno pelo ID e retorna seus dados caso ele esteja com a matrícula ativa
int db_read(int id, Aluno *out) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return 0;

    Aluno temp; 
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id == id) {
            *out = temp;
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Função para localizar um aluno pelo ID e sobrescreve seus dados no arquivo com as novas informações
int db_update(int id, const Aluno *novo) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Aluno temp;
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id == id && temp.matriculado) {
            fseek(f, -(long)sizeof(Aluno), SEEK_CUR);
            Aluno atualizado = *novo;
            atualizado.id = id;
            atualizado.matriculado = 1;
            fwrite(&atualizado, sizeof(Aluno), 1, f);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Função para realizar a exclusão lógica do aluno, alterando o campo 'matriculado' para 0 (Inativo)
int db_delete(int id) {
    FILE *f = fopen(DB_FILE, "rb+");
    if (!f) return 0;

    Aluno temp;
    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.id == id) {
            temp.matriculado = 0;
            fseek(f, -(long)sizeof(Aluno), SEEK_CUR);
            fwrite(&temp, sizeof(Aluno), 1, f);
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

// Função para apagar permanentemente todos os registros do arquivo
int db_delete_all(void) {
    FILE *f = fopen(DB_FILE, "wb");
    if (!f) return 0;
    fclose(f);
    return 1;
}

// --- FUNÇÕES DE LISTAGEM  ---

//Função para ler todos os alunos ativos e os exibe na ordem em que foram gravados no arquivo
void db_list_table(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) {
        lista[count++] = temp;
    }
    fclose(f);

    printf("\n>>> TABELA GERAL (ATIVOS E INATIVOS)");
    renderizar_tabela(lista, count);
}

//Função para carregar os alunos ativos na memória e os ordena de forma crescente pelo número do ID
void db_list_sorted_by_id(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) lista[count++] = temp;
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (lista[j].id > lista[j + 1].id) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> LISTA POR ID (CRESCENTE)");
    renderizar_tabela(lista, count);
}

//Função para carregar os alunos ativos na memória e os ordena em ordem alfabética (A-Z)
void db_list_sorted_by_name(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f)) {
        if (temp.matriculado && count < MAX_REGISTROS) lista[count++] = temp;
    }
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (strcmp(lista[j].nome, lista[j + 1].nome) > 0) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> LISTA POR NOME (ALFABETICA)");
    renderizar_tabela(lista, count);
}

// Função para carregar os alunos ativos e os ordena da maior para a menor frequência
void db_list_sorted_by_freq(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) lista[count++] = temp;
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (lista[j].frequencia < lista[j + 1].frequencia) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> RANKING POR FREQUENCIA (MAIOR -> MENOR)");
    renderizar_tabela(lista, count);
}

//Função para carregar os alunos ativos e os ordena da maior para a menor média final (Ranking)
void db_list_sorted_by_grade(void) {
    FILE *f = fopen(DB_FILE, "rb");
    if (!f) return;

    Aluno lista[MAX_REGISTROS];
    int count = 0;
    Aluno temp;

    while (fread(&temp, sizeof(Aluno), 1, f) && count < MAX_REGISTROS) lista[count++] = temp;
    fclose(f);

    for (int i = 0; i < count - 1; i++) {
        for (int j = 0; j < count - i - 1; j++) {
            if (lista[j].media < lista[j + 1].media) {
                Aluno aux = lista[j];
                lista[j] = lista[j + 1];
                lista[j + 1] = aux;
            }
        }
    }
    printf("\n>>> RANKING POR NOTA (MAIOR -> MENOR)");
    renderizar_tabela(lista, count);
}

