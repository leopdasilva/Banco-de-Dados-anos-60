#include "db.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

// Limpa o lixo do buffer do teclado
void limpar_buffer() {
    int c;
    while ((c = getchar()) != '\n' && c != EOF);
}

// Limpa a tela do terminal dependendo do SO
void limpar_tela() {
    #ifdef _WIN32
        system("cls");
    #else
        system("clear");
    #endif
}

int main(void) {
    db_init();
    int opcao;

    do {
        printf("\n--- MENU SISTEMA ACADEMICO ---\n");
        printf("1. Cadastrar Aluno\n");
        printf("2. Listar por ID\n");
        printf("3. Listar por Nome\n");
        printf("4. Listar por Frequencia\n");
        printf("5. Listar por Nota\n");
        printf("6. Visualizar Tabela Completa (Historico)\n");
        printf("7. Desativar Aluno (Excluir Logico)\n");
        printf("8. Apagar Banco de Dados Inteiro (Reset)\n");
        printf("0. Sair\n");
        printf("Escolha: ");
        
        if (scanf("%d", &opcao) != 1) {
            limpar_buffer();
            continue;
        }
        limpar_buffer();

        if (opcao == 1) {
            Aluno novo;
            limpar_tela();
            novo.id = db_next_id();
            printf("ID gerado: %d\n", novo.id);
            
            printf("Nome: "); 
            fgets(novo.nome, NAME_SIZE, stdin);
            novo.nome[strcspn(novo.nome, "\n")] = 0;

            printf("CPF: "); scanf("%s", novo.cpf);
            printf("Media: "); scanf("%f", &novo.media);
            printf("Frequencia: "); scanf("%d", &novo.frequencia);
            limpar_buffer(); // Importante limpar após scanfs numericos
            
            novo.matriculado = 1;
            char mats[QTD_MATERIAS][MATERIA_SIZE] = MATERIAS;
            for(int i=0; i<QTD_MATERIAS; i++) strcpy(novo.materias[i], mats[i]);

            if(db_create(&novo)) printf("\n[OK] Aluno salvo com sucesso!\n");

        } else if (opcao >= 2 && opcao <= 6) {
            limpar_tela();
            if (opcao == 2) db_list_sorted_by_id();
            else if (opcao == 3) db_list_sorted_by_name();
            else if (opcao == 4) db_list_sorted_by_freq();
            else if (opcao == 5) db_list_sorted_by_grade();
            else if (opcao == 6) db_list_table();

        } else if (opcao == 7) {
            limpar_tela();
            int id_busca;
            Aluno temp;
            printf("Digite o ID para desativar: ");
            scanf("%d", &id_busca);
            limpar_buffer();

            if (db_read(id_busca, &temp)) {
                if (!temp.matriculado) {
                    printf("\n[!] Aluno ja se encontra INATIVO.\n");
                } else {
                    char confirma;
                    printf("Desativar [%s]? (s/n): ", temp.nome);
                    scanf("%c", &confirma);
                    limpar_buffer();
                    if (tolower(confirma) == 's') {
                        db_delete(id_busca);
                        printf("\n[OK] Status alterado para INATIVO.\n");
                    }
                }
            } else {
                printf("\n[ERRO] ID nao encontrado.\n");
            }

        } else if (opcao == 8) {
            limpar_tela();
            char confirma1, confirma2;
            printf("\n!!! PERIGO: ESTA OPERACAO APAGARA TODOS OS ALUNOS !!!\n");
            printf("Deseja continuar? (s/n): ");
            scanf(" %c", &confirma1); 

            if (tolower(confirma1) == 's') {
                printf("CONFIRMACAO FINAL: Apagar tudo? (s/n): ");
                scanf(" %c", &confirma2);
                if (tolower(confirma2) == 's') {
                    if (db_delete_all()) {
                        printf("\n[SUCESSO] Banco de dados resetado.\n");
                    } else {
                        printf("\n[ERRO] Falha ao acessar o arquivo.\n");
                    }
                }
            }
            limpar_buffer();
        }
    } while (opcao != 0);

    printf("\nSaindo do sistema...\n");
    return 0;
}