#ifndef DB_H
#define DB_H

#include <stdio.h>
#include <stdbool.h>

#define DB_FILE "database.bin"
#define NAME_SIZE 50
#define CPF_SIZE 12
#define MAX_REGISTROS 30
#define QTD_MATERIAS 3
#define MATERIA_SIZE 50
#define MATERIAS { \
    "Banco de dados", \
    "Programação de Aplicativos", \
    "Internet das Coisas(IOT)" \
}

// Struct para armazear dados de um aluno
typedef struct{  
    int id; // ID referente ao aluno cadastrado
    char nome[NAME_SIZE]; // Nome do aluno
    char cpf[CPF_SIZE]; // CPF do aluno
    char data_nasc[9]; // Data de nascimento do aluno
    float media; // Media do aluno a ser cadastrado
    int frequencia; // Frequência do aluno a ser cadastrado
    bool situacao; // Situação do aluno ao comparar media e frequencia. True = Aprovado e False = Reprovado
    int matriculado; // Para fins de observar se o aluno está com a matricula ativa ou não. 0 = inativo, 1 = ativo
    char materias[QTD_MATERIAS][MATERIA_SIZE]; // Para definir o a quantidade de matérias e o numero de caracteres a ser usado
}Aluno;

// Funções
int db_init(); 
int db_next_id();
int db_create(const Aluno *reg);
int db_update(int id, const Aluno *novo);
int db_delete(int id);
int db_read(int id, Aluno *out);
void db_list_sorted_by_id(void);
void db_list_sorted_by_name(void);
void db_list_sorted_by_freq(void);
void db_list_sorted_by_grade(void);
int db_get_all(Aluno *out_lista, int max_registros);
void db_list_table(void);
int db_delete_all(void);

#endif