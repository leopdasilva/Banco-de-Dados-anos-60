import ctypes
import os
import sys

# --- CONFIGURAÇÕES ---
DB_FILE = "database.bin"
NAME_SIZE = 50
CPF_SIZE = 12
QTD_MATERIAS = 3
MATERIA_SIZE = 50
MAX_REGISTROS = 30

class Aluno(ctypes.Structure):
    _fields_ = [
        ("id", ctypes.c_int),
        ("nome", ctypes.c_char * NAME_SIZE),
        ("cpf", ctypes.c_char * CPF_SIZE),
        ("data_nasc", ctypes.c_char * 9),
        ("media", ctypes.c_float),
        ("frequencia", ctypes.c_int),
        ("situacao", ctypes.c_bool),      
        ("matriculado", ctypes.c_int),   
        ("materias", (ctypes.c_char * MATERIA_SIZE) * QTD_MATERIAS)
    ]

diretorio_atual = os.path.dirname(os.path.abspath(__file__))
dll_path = os.path.join(diretorio_atual, "db.dll")

try:
    if os.name == 'nt':
        os.add_dll_directory(diretorio_atual)
    lib = ctypes.CDLL(dll_path)
    print("✓ DLL carregada para operações de escrita.")
except Exception as e:
    print(f"✗ Erro ao carregar DLL: {e}")
    sys.exit(1)

class DBService:
    @staticmethod
    def init():
        return lib.db_init()

    @staticmethod
    def get_next_id():
        return lib.db_next_id()

    @staticmethod
    def create(nome, cpf, media, frequencia):
        novo = Aluno()
        novo.id = DBService.get_next_id()
        novo.nome = nome.encode('utf-8')[:NAME_SIZE-1]
        novo.cpf = cpf.encode('utf-8')[:CPF_SIZE-1]
        novo.data_nasc = b"00000000"
        novo.media = float(media)
        novo.frequencia = int(frequencia)
        novo.matriculado = 1
        return lib.db_create(ctypes.byref(novo))

    @staticmethod
    def delete(id_aluno):
        return lib.db_delete(id_aluno)

    @staticmethod
    def delete_all():
        return lib.db_delete_all()

    @staticmethod
    def update(id_aluno, nome, cpf, media, frequencia):
        """Chama a função de sobrescrita da DLL"""
        lib.db_update.argtypes = [ctypes.c_int, ctypes.POINTER(Aluno)]
        lib.db_update.restype = ctypes.c_int
        
        novo = Aluno()
        novo.nome = nome.encode('utf-8')[:NAME_SIZE-1]
        novo.cpf = cpf.encode('utf-8')[:CPF_SIZE-1]
        novo.media = float(media)
        novo.frequencia = int(frequencia)
        # data_nasc e outros campos podem ser vázios ou mantidos
        
        return lib.db_update(id_aluno, ctypes.byref(novo))

    @staticmethod
    def get_todos(ordem="id"):
        """Lê o binário e permite ordenar por diferentes critérios"""
        alunos_python = []
        caminho_db = os.path.join(diretorio_atual, "database.bin")
        
        if not os.path.exists(caminho_db): return []

        with open(caminho_db, "rb") as f:
            while True:
                buffer = f.read(ctypes.sizeof(Aluno))
                if not buffer: break
                a = Aluno.from_buffer_copy(buffer)
                if a.matriculado == 1:
                    alunos_python.append({
                        "id": a.id,
                        "nome": a.nome.decode('utf-8', errors='ignore').strip('\x00'),
                        "cpf": a.cpf.decode('utf-8', errors='ignore').strip('\x00'),
                        "media": round(a.media, 2),
                        "frequencia": a.frequencia,
                        "status": "ATIVO"
                    })

        # Implementação das lógicas de ordenação do seu db.c no Python
        if ordem == "nome":
            alunos_python.sort(key=lambda x: x["nome"].lower())
        elif ordem == "nota":
            alunos_python.sort(key=lambda x: x["media"], reverse=True)
        elif ordem == "freq":
            alunos_python.sort(key=lambda x: x["frequencia"], reverse=True)
        else: # padrão ID
            alunos_python.sort(key=lambda x: x["id"])
            
        return alunos_python