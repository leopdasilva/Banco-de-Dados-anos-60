import tkinter as tk
from tkinter import ttk, messagebox
from db_service import DBService

class MiniDBStudio(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Sistema Acadêmico Pro - DB Engine")
        self.geometry("1000x650")
        self.db = DBService()
        self.db.init()
        self.ordem_atual = "id" # Estado da ordenação
        self._criar_layout()
        self.listar_todos()

    def _criar_layout(self):
        # --- Toolbar Superior (Ordenação) ---
        toolbar = ttk.LabelFrame(self, text=" Organizar Lista ")
        toolbar.pack(fill=tk.X, padx=10, pady=5)
        
        ttk.Button(toolbar, text="Por ID (1-9)", command=lambda: self.reordenar("id")).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(toolbar, text="Por Nome (A-Z)", command=lambda: self.reordenar("nome")).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(toolbar, text="Ranking Notas", command=lambda: self.reordenar("nota")).pack(side=tk.LEFT, padx=5, pady=5)
        ttk.Button(toolbar, text="Ranking Freq.", command=lambda: self.reordenar("freq")).pack(side=tk.LEFT, padx=5, pady=5)

        # --- Área Central (Formulário e Tabela) ---
        container = ttk.Frame(self)
        container.pack(fill=tk.BOTH, expand=True, padx=10)

        # Formulário
        form = ttk.LabelFrame(container, text=" Ficha do Aluno ")
        form.pack(fill=tk.X, pady=5)
        
        # Grid do Formulário
        ttk.Label(form, text="ID:").grid(row=0, column=0, padx=5)
        self.ent_id = ttk.Entry(form, width=8, state="readonly") # ID é gerado pelo sistema
        self.ent_id.grid(row=0, column=1, sticky="w", padx=5, pady=5)

        ttk.Label(form, text="Nome:").grid(row=0, column=2, padx=5)
        self.ent_nome = ttk.Entry(form, width=35)
        self.ent_nome.grid(row=0, column=3, padx=5)

        ttk.Label(form, text="CPF:").grid(row=1, column=0, padx=5)
        self.ent_cpf = ttk.Entry(form, width=15)
        self.ent_cpf.grid(row=1, column=1, padx=5)

        ttk.Label(form, text="Média:").grid(row=1, column=2, padx=5, sticky="e")
        self.ent_media = ttk.Entry(form, width=8)
        self.ent_media.grid(row=1, column=3, sticky="w", padx=5)

        ttk.Label(form, text="Frequência %:").grid(row=1, column=3, padx=5, sticky="e")
        self.ent_freq = ttk.Entry(form, width=8)
        self.ent_freq.grid(row=1, column=4, padx=5)

        # Botões de Ação
        btn_frame = ttk.Frame(container)
        btn_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(btn_frame, text="Novo / Limpar", command=self._limpar).pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="SALVAR / INSERIR", command=self.salvar, style="Accent.TButton").pack(side=tk.LEFT, padx=5)
        ttk.Button(btn_frame, text="DESATIVAR ALUNO", command=self.excluir).pack(side=tk.RIGHT, padx=5)

        # Tabela
        cols = ("id", "nome", "cpf", "media", "freq", "situacao")
        self.tabela = ttk.Treeview(container, columns=cols, show="headings", height=15)
        for c, h in zip(cols, ["ID", "NOME COMPLETO", "CPF", "MÉDIA", "FREQ", "SITUAÇÃO"]):
            self.tabela.heading(c, text=h)
            self.tabela.column(c, width=80 if len(c)<4 else 250, anchor="center")
        
        self.tabela.pack(fill=tk.BOTH, expand=True)
        self.tabela.bind("<<TreeviewSelect>>", self.carregar_selecionado)

    def reordenar(self, criterio):
        self.ordem_atual = criterio
        self.listar_todos()

    def salvar(self):
        id_str = self.ent_id.get()
        nome, cpf = self.ent_nome.get(), self.ent_cpf.get()
        media, freq = self.ent_media.get(), self.ent_freq.get()

        if not id_str: # Inserir novo
            if self.db.create(nome, cpf, media, freq):
                messagebox.showinfo("Sucesso", "Aluno cadastrado!")
        else: # Editar existente
            if self.db.update(int(id_str), nome, cpf, media, freq):
                messagebox.showinfo("Sucesso", "Dados atualizados!")
        
        self.listar_todos()
        self._limpar()

    def carregar_selecionado(self, event):
        item = self.tabela.selection()
        if not item: return
        val = self.tabela.item(item, "values")
        
        self._limpar()
        self.ent_id.config(state="normal")
        self.ent_id.insert(0, val[0])
        self.ent_id.config(state="readonly")
        self.ent_nome.insert(0, val[1])
        self.ent_cpf.insert(0, val[2])
        self.ent_media.insert(0, val[3])
        self.ent_freq.insert(0, val[4].replace('%',''))

    def excluir(self):
        id_str = self.ent_id.get()
        if id_str and messagebox.askyesno("Confirmar", "Deseja desativar este aluno?"):
            self.db.delete(int(id_str))
            self.listar_todos()
            self._limpar()

    def listar_todos(self):
        for i in self.tabela.get_children(): self.tabela.delete(i)
        registros = self.db.get_todos(self.ordem_atual)
        for a in registros:
            sit = "APROVADO" if (a["media"] >= 7 and a["frequencia"] >= 75) else "REPROVADO"
            self.tabela.insert("", "end", values=(a["id"], a["nome"], a["cpf"], a["media"], f"{a['frequencia']}%", sit))

    def _limpar(self):
        self.ent_id.config(state="normal")
        for e in [self.ent_id, self.ent_nome, self.ent_cpf, self.ent_media, self.ent_freq]:
            e.delete(0, tk.END)
        self.ent_id.config(state="readonly")

if __name__ == "__main__":
    app = MiniDBStudio()
    app.mainloop()